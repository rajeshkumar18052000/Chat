import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';

const ChatRoom = () => {
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState('');
  const [socket, setSocket] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    // Initialize socket connection
    const newSocket = io('http://localhost:5000');
    setSocket(newSocket);

    // Clean up socket connection on unmount
    return () => newSocket.disconnect();
  }, []);

  useEffect(() => {
    if (!socket) return;

    socket.on('receive_message', (data) => {
      setMessages((prev) => [...prev, data]);
    });

    socket.on('connect_error', (error) => {
      setError('Failed to connect to chat server');
    });

    // Clean up listeners
    return () => {
      socket.off('receive_message');
      socket.off('connect_error');
    };
  }, [socket]);

  const sendMessage = (e) => {
    e.preventDefault();
    if (!message.trim() || !socket) return;

    const user = JSON.parse(localStorage.getItem('user'));
    
    socket.emit('send_message', {
      sender: user?.username || 'Anonymous',
      message: message.trim()
    });
    
    setMessage('');
  };

  return (
    <div className="chat-container">
      <div className="messages-container">
        {error && <div className="error-message">{error}</div>}
        {messages.map((msg, index) => (
          <div key={index} className="message">
            <strong>{msg.sender}:</strong> {msg.message}
          </div>
        ))}
      </div>
      <form onSubmit={sendMessage} className="message-form">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          className="message-input"
        />
        <button type="submit" className="send-button">Send</button>
      </form>
    </div>
  );
};

export default ChatRoom;
